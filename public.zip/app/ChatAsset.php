<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatAsset extends Model
{
    protected $guarded = [];
}
