<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatLike extends Model
{
    protected $guarded = [];
}
