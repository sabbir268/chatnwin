<?php

namespace App\Http\Controllers;

use App\ChatAsset;
use Illuminate\Http\Request;

class ChatAssetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ChatAsset  $chatAsset
     * @return \Illuminate\Http\Response
     */
    public function show(ChatAsset $chatAsset)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ChatAsset  $chatAsset
     * @return \Illuminate\Http\Response
     */
    public function edit(ChatAsset $chatAsset)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ChatAsset  $chatAsset
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ChatAsset $chatAsset)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ChatAsset  $chatAsset
     * @return \Illuminate\Http\Response
     */
    public function destroy(ChatAsset $chatAsset)
    {
        //
    }
}
