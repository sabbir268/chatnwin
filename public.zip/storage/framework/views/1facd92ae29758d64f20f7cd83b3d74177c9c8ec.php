<style>
    .card.card-statistics {
        background: linear-gradient(85deg, #06b76b, #f5a623);
        color: #ffffff;
    }

    .winners-single {
        margin-bottom: 45px;
    }

    .winners-single h5 {
        font-size: 23px;
        font-weight: normal;
        margin-top: 20px;
    }

</style>
<?php $__env->startSection('content'); ?>
<div class="main-panel" style="width: 100% !important;">
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">

            </h3>
        </div>
        <div class="row grid-margin">
            <div class="col-12">
                <?php $__currentLoopData = $winners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $winner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="winners-single">
                    <h4><?php echo e($winner->user->username); ?></h4>
                    <h5> <b>Chatroom:</b> <?php echo e($winner->chatRoom->name); ?>,<b>Size:</b> <?php echo e($winner->size); ?>, <b>Address:</b><?php echo e($winner->user->address); ?></h5>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal\ssabbir-vai\sneakly-development\resources\views/admin/winners.blade.php ENDPATH**/ ?>