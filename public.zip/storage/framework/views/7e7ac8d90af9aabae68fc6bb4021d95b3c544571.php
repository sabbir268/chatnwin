<?php $__env->startSection('header'); ?>
<title>Sneakly</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu-item'); ?>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('terms-services')); ?>">Terms</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('privacy-policy')); ?>">Privacy</a>
  </li>
  <?php if(!Auth::check()): ?>
  <li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('login')); ?>">Login</a>
  </li>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="about-us-header">
        <h1 class="font-weight-bold">ABOUT US</h1>
        <p>CHAT AND WIN COOL PRIZES WHILE YOU’RE AT IT </p>
    </div>
<div class="About-us-main">
    <div class="row">
        <div class="col-md-4 col-lg-4">
            <div class="about-us-single">
                <img src="<?php echo e(asset('assets/frontend/images/about/focus-center-weak-photo-image.png')); ?>" alt="image">
                <p>PAY $1 TO GET ACCESS TO A CHAT ROOM ABOUT HYPED ITEMS</p>
            </div>
          </div>
          <div class="col-md-4 col-lg-4">
            <div class="about-us-single">
                <img src="<?php echo e(asset('assets/frontend/images/about/party-horn-event-celebrate-funny.png')); ?>" alt="image">
                <p>CHOP IT UP ABOUT ANYTHING IN THE CHAT ROOM</p>
            </div>
          </div>
          <div class="col-md-4 col-lg-4">
            <div class="about-us-single">
                <img src="<?php echo e(asset('assets/frontend/images/about/chat-bubble-message-speech-conversation-comomment-chating.png')); ?>" alt="image">
                <p>EACH WEEK ONE PERSON FROM EVERY CHAT ROOM WILL RECEIVE A FREE BONUS</p>
            </div>
          </div>
     </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal\ssabbir-vai\sneakly-development\resources\views/frontend/about.blade.php ENDPATH**/ ?>