<?php $__env->startSection('header'); ?>
<title>Sneakly</title>
<style>
  @media  only screen and (max-width: 600px) {
    h1 {
      font-size: 18px !important;
    }
    .chatroom-single h3 {
    font-size: 12px;
}
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu-item'); ?>
<li class="nav-item">
  <a class="nav-link" href="<?php echo e(url('about')); ?>">About</a>
</li>
<?php if(!Auth::check()): ?>
<li class="nav-item">
  <a class="nav-link" href="<?php echo e(url('login')); ?>">Login</a>
</li>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(Session::has('first_time')): ?>
<div class="preloader" id="preloaders"></div> 
<?php endif; ?>
<div class="row m-0 p-0">
  

  <div class="col-md-10 col-lg-10 offset-md-1 offset-lg-1">
    <h1 class="mb-5 font-weight-bold">Choose a chat room about an item you have or want to have </h1>
    <div class="chatroom-area">
      <div class="row">


        
    

    <?php $__currentLoopData = $chatrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 col-lg-4 col-sm-6 col-6">
      <div class="chatroom-single">
        <?php if(auth()->check()): ?>
          <?php if(checkJoined($chatroom->id, auth()->user()->id)): ?>
              <a href="<?php echo e(route('chatroom', $chatroom->slug)); ?>">
          <?php else: ?> 
            <a href="javascript::void(0)" data-url="<?php echo e(route('chatroom', $chatroom->slug)); ?>" class="enter-chatroom">
          <?php endif; ?>
        <?php else: ?> 
          <a href="<?php echo e(route('chatroom', $chatroom->slug)); ?>">
        <?php endif; ?>
          <img src="<?php echo e(asset('storage/'.$chatroom->photo)); ?>" alt="chatroom-image" style="width: 100%">
          <h3><?php echo e($chatroom->name); ?></h3>
        </a>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>
</div>
</div>

<!-- modal -->

<div class="modal fadeIn" id="confirmModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded-0">
      <div class="modal-body">
        <div class="welcome-message p-3 text-center">
          <p class="font-weight-bolder">Do you want to pay $1 to access this Chat Room?</p>
          <a href="javascript::void(0)" data-dismiss="modal"
            class="btn btn-primary rounded-0 border-sn bg-snw pl-5 pr-5 pt-2 pb-2">No</a>
          <a href="#" id="goChatroom" class="btn btn-primary rounded-0 border-sn bg-snw pl-5 pr-5 pt-2 pb-2">Ok</a>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script>
  $(document).ready(function() {
      $('.enter-chatroom').click(function() {
          $url = $(this).data('url');
          $('#goChatroom').attr("href", $url);
          $('#confirmModal').modal('show');
      });
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal\ssabbir-vai\sneakly-development\resources\views/frontend/index.blade.php ENDPATH**/ ?>